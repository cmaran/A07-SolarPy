Sun-Class
========

Sun
------------

.. py:currentmodule:: sphere.Sun
.. autoclass:: Sun
	:members:
	
..autofunction:: __init__




