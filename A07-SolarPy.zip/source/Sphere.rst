Sphere-Class
========

Sphere
------------

.. py:currentmodule:: sphere.Sphere
.. autoclass:: Sphere
	:members:
	
..autofunction:: __init__




