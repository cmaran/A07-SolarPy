Moon-Class
========

Moon
------------

.. py:currentmodule:: sphere.Moon
.. autoclass:: Moon
	:members:
	
..autofunction:: __init__




