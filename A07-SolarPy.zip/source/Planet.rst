Planet-Class
========

Planet
------------

.. py:currentmodule:: sphere.Planet
.. autoclass:: Planet
	:members:
	
..autofunction:: __init__




