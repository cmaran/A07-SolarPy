Light-Class
========

Light
------------

.. py:currentmodule:: utils.Light
.. autoclass:: Light
	:members:
	
..autofunction:: __init__




