CamView-Class
========

CamView
------------

.. py:currentmodule:: utils.CamView
.. autoclass:: CamView
	:members:
	
..autofunction:: __init__




