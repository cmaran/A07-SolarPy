Window-Class
========

Window
------------

.. py:currentmodule:: window.Window
.. autoclass:: Window
	:members:
	
..autofunction:: __init__




